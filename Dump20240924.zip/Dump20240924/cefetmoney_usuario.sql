CREATE DATABASE  IF NOT EXISTS `cefetmoney` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci */;
USE `cefetmoney`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: cefetmoney
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `idUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `nomeUsuario` varchar(100) NOT NULL,
  `cpfUsuario` varchar(14) NOT NULL,
  `senhaUsuario` varchar(255) NOT NULL,
  `emailUsuario` varchar(100) NOT NULL,
  `cidadeUsuario` varchar(50) DEFAULT NULL,
  `bairroUsuario` varchar(50) DEFAULT NULL,
  `ruaUsuario` varchar(100) DEFAULT NULL,
  `numeroUsuario` int(11) DEFAULT NULL,
  `complementoUsuario` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (3,'Gabriel Ribeiro Passos','134.077.196-98','$2b$10$3RBbc9H4STpQjCisXunk6eN1FVrolvzP83XPUxM84kYU3pxw6vXFe','leirbagrp@gmail.com',NULL,NULL,NULL,NULL,NULL),(4,'iuri sousa werneck pereira','137.986.676-67','$2b$10$dd756rTTHMR6WYT6EX32w.gpMAqJAHOcNlowCfJCGaGCi7iEY3BOW','iuriwerneck10@gmail.com','Cataguases','José Gabriel de Passos','Rua Sigismundo Ferreira',779,'apto 203'),(5,'teste','530.355.006-06','$2b$10$Rr6MrTHdnJIT523cHEXn6umqeuIfguEBQVaz/2JVvAUjEBOsiNvb2','email@gmail.com',NULL,NULL,NULL,NULL,NULL),(6,'iuri sousa werneck pereira','506.753.540-72','$2b$10$MgY3L.86goVft4y2H6yOdepuS6.y2m0t4OVQd2c1rgJT1Q5E361DG','guoxin6764@uorak.com',NULL,NULL,NULL,NULL,NULL),(7,'gabriel ribeiro passos','276.303.760-73','$2b$10$29zQ5llZW8t9r7WqElu5FeMvV0.9JLKfUL/VCexRuy7yXeOulEJNa','gabriel@email.com',NULL,NULL,NULL,NULL,NULL),(8,'teste teste teste','906.796.450-63','$2b$10$EWbgKUfYh7Lz2kRgSbMDruXY8XIuHlYo3L1hPdErk4z9RvoSYOsy2','teste@gmail.com',NULL,NULL,NULL,NULL,NULL),(9,'iuri sousa werneck','emailteste@gma','$2b$10$jHE1pTj1Ov/LXVPaxU5LIuT9eSd8DZAx1Bo9MDqApDUucZufWPCtC','654.946.150-22',NULL,NULL,NULL,NULL,NULL),(10,'iuri sousa werneck','654.946.150-22','$2b$10$1DocpybDLRoaJ3IWZYtBcecjcg3nka4zrYKGD/538qrps1dV1YRHe','emailteste@gmail.com',NULL,NULL,NULL,NULL,NULL),(20,'vinicius lima','430.747.470-80','$2b$10$3cDBNvLBgb7.8rnCOm8EQuX2gHsAzIgbpqJgK36YucjHv3XdN9O/C','viniciuspet@gmail.com',NULL,NULL,NULL,NULL,NULL),(21,'Dino La Gatta Oliveira','228.528.910-34','$2b$10$Sy26558p1ImV4qUYtUvaK.C.euVraMtgZZFTErIElkilRMAWf26n2','bruno55255@gmail.com',NULL,NULL,NULL,NULL,NULL),(22,'gabriella','084.637.166-95','$2b$10$kfHIa4KgESnKLb8y7i3mcezT7UdhLF2NLAht0WRVMTFpSuXpgoy.m','gabriellateste@gmail.com',NULL,NULL,NULL,NULL,NULL),(23,'professor cefet','137.986.686-67','$2b$10$5l0h8Oy1iJqOpZWH0HQs8eksuiqB0kArup4nTtG1m3UUzCTb0bBoa','cefet@gmail.com','Leopoldina','Centro','Rua Idalina Gomes Domingues',20,'apto 201');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-24  7:42:39
